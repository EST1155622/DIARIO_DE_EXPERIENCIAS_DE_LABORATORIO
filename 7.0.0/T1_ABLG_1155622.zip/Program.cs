﻿//El proyecto que se acaba de crear, en Visual Studio C# para Consola, ¿utiliza uncompilador o un intérprete para ejecutarse? ¿Por qué? 
//Respuesta: utiliza un intérprete, porque no puede ejecutarse por si solo. Se requieren de datos ingresados. 
//Para el proyecto "Hola mundo", la entrada era la variable "nombre", no habian procesos y las salidas eran "Hola mundo" y "soy + nombre". 


    Console.WriteLine("Mi segundo programa ");

    Console.WriteLine("Por favor ingresa tu nombre");
    string Nombre = Console.ReadLine();
    Console.WriteLine("Por favor ingresa tu edad");
    string Edad = Console.ReadLine();
    Console.WriteLine("Por favor ingresa el nombre de tu carrera");
    string Carrera = Console.ReadLine();
    Console.WriteLine("Por favor ingresa tu carné");
    string Carne = Console.ReadLine();


    {
        Console.WriteLine("Nombre " + Nombre);
        Console.WriteLine("Edad " + Edad);
        Console.WriteLine("Carrera " + Carrera);
        Console.WriteLine("Carne " + Carne);    
    }

{
    Console.Write("Soy " + Nombre);
    Console.Write(",");
    Console.Write(" tengo " + Edad);
    Console.Write(" años y estudio la carrera de "+ Carrera);
    Console.WriteLine(".");
    Console.Write("Mi número de carné es: " + Carne);

 }

    Console.ReadKey(); 
