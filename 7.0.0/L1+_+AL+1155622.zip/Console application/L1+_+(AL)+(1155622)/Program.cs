﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string NOMBRE =Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy_"  + NOMBRE);

        /*En relación con las diferencias entre "Console.WriteLine" y "Console.Write", Console.WriteLine escribe la
         frase deseada por cada línea, en cambio Console.Write escribe todos los "Console.Write" seguidos, es decir, 
        en una misma línea y sin dejar espacios entre el final e inicio de las frases*/ 
        
        Console.Write("Hola Mundo");
        Console.Write("soy_"  + NOMBRE);
        Console.ReadKey(); 

    }
}
